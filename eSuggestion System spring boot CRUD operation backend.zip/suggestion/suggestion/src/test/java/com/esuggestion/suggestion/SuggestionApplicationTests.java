package com.esuggestion.suggestion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuggestionApplicationTests {

	@Test
	void contextLoads() {
	}

}
