package com.esuggestion.suggestion.controller;

import com.esuggestion.suggestion.model.Employee;
import com.esuggestion.suggestion.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.MediaType;

import java.util.*;

@RestController
@RequestMapping("/api/employees")
@CrossOrigin("*")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping(value = "/readEmployee")
    public ResponseEntity<List<Employee>> readEmployee(){
        List<Employee> s = employeeService.readAllEmployees();     
            return ResponseEntity.ok(s);   
    }
    @GetMapping(value = "/readEmployeeById/{id}")
    public ResponseEntity<?> readEmployeeById(@PathVariable UUID id){
        Optional<Employee> s = employeeService.readEmployeeById(id);     
            return s.isPresent() ? ResponseEntity.ok(s) : ResponseEntity.notFound().build();   
    }

    @PostMapping(value = "/createEmployee", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> createEmployee(@RequestBody Employee employee) {

        String saveEmployee = employeeService.createEmployee(employee);

        if (saveEmployee.equals("Employee success")) {
            return new ResponseEntity<>(saveEmployee, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(saveEmployee, HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping(value = "/removeEmployeeById/{id}")
    public ResponseEntity<?> removeEmployeeById(@PathVariable UUID id){
        String s = employeeService.deleteEmployee(id);
        if (s.equals("Employee Deleted")) {
            return ResponseEntity.ok(s);
        }else{
            return ResponseEntity.notFound().build();
        }
    }
    @PutMapping(value = "/changeEmployee/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> changeEmployee(@PathVariable UUID id,@RequestBody Employee employee){
        String s = employeeService.changeEmployee(id, employee);
        if (s.equals("Employee Changed")) {
            return ResponseEntity.ok(s);
        }else{
            return ResponseEntity.notFound().build();
        }
    }
    
}
