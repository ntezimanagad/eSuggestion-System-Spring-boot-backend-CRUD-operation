package com.esuggestion.suggestion.service;

import com.esuggestion.suggestion.model.Suggestion;
import com.esuggestion.suggestion.repository.SuggestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class SuggestionService {

    @Autowired
    private SuggestionRepository suggestionRepository;

    public List<Suggestion> readAllSuggestions() {
        return suggestionRepository.findAll();
    }

    public Optional<Suggestion> readSuggestionById(UUID id) {
        return suggestionRepository.findById(id);
    }

    public List<Suggestion> readSuggestionsByStatus(String status) {
        return suggestionRepository.findByStatus(status);
    }

    public List<Suggestion> readSuggestionsByEmployeeId(UUID employeeId) {
        return suggestionRepository.findByEmployeeId(employeeId);
    }

    public String createSuggestion(Suggestion suggestion) {
        Optional<Suggestion> sugge = suggestionRepository.findBytitle(suggestion.getTitle());

        if (sugge.isPresent()) {
            return "Suggestion Exist";
        }else{
            suggestionRepository.save(suggestion);
            return "Suggestion success";
        }
    }

    public String deleteSuggestion(UUID id) {
        Optional<Suggestion> s = suggestionRepository.findById(id);
        if (s.isPresent()) {
            suggestionRepository.deleteById(id);
            return "Suggestion Deleted";
        }else{
            return "failed to delete";
        }
    }
    public String changeSuggestion( UUID id, Suggestion suggestion){
        Optional<Suggestion> s = suggestionRepository.findById(id);
        if (s.isPresent()) {
            Suggestion ss = s.get();
            ss.setTitle(suggestion.getTitle());
            ss.setDescription(suggestion.getDescription());
            ss.setStatus(suggestion.getStatus());
            ss.setSuggestionType(suggestion.getSuggestionType());
            suggestionRepository.save(ss);
            return "Suggestion Changed";
        }else{
            return "Suggestion Not Changed";
        }
    }
    
}
