package com.esuggestion.suggestion.controller;

import com.esuggestion.suggestion.model.Suggestion;
import com.esuggestion.suggestion.service.SuggestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/suggestions")
public class SuggestionController {

    @Autowired
    private SuggestionService suggestionService;

    @GetMapping(value = "/readSuggestion")
    public ResponseEntity<List<Suggestion>> readSuggestion(){
        List<Suggestion> s = suggestionService.readAllSuggestions();     
            return ResponseEntity.ok(s);   
    }
    @GetMapping(value = "/readSuggestionById/{id}")
    public ResponseEntity<?> readSuggestionById(@PathVariable UUID id){
        Optional<Suggestion> s = suggestionService.readSuggestionById(id);     
            return s.isPresent() ? ResponseEntity.ok(s) : ResponseEntity.notFound().build();   
    }
    @GetMapping(value = "/status/{status}")
    public ResponseEntity<List<Suggestion>> readSuggestionByStatus(@PathVariable String sugge){
        List<Suggestion> s = suggestionService.readSuggestionsByStatus(sugge);     
            return ResponseEntity.ok(s);   
    }
    @GetMapping(value = "/readSuggestionByEmpId/{id}")
    public ResponseEntity<List<Suggestion>> readSuggestionByEmpId(@PathVariable UUID id){
        List<Suggestion> s = suggestionService.readSuggestionsByEmployeeId(id);     
            return ResponseEntity.ok(s);   
    }

    @PostMapping(value = "/createSuggestion", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> createSuggestion(@RequestBody Suggestion sugge) {

        String saveSuggestion = suggestionService.createSuggestion(sugge);

        if (saveSuggestion.equals("Suggestion success")) {
            return new ResponseEntity<>(saveSuggestion, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(saveSuggestion, HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping(value = "/removeSuggestionById/{id}")
    public ResponseEntity<?> removeSuggestionById(@PathVariable UUID id){
        String s = suggestionService.deleteSuggestion(id);
        if (s.equals("Suggestion Deleted")) {
            return ResponseEntity.ok(s);
        }else{
            return ResponseEntity.notFound().build();
        }
    }
    @PutMapping(value = "/changeSuggestion/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> changeSuggestion(@PathVariable UUID id,@RequestBody Suggestion sugge){
        String s = suggestionService.changeSuggestion(id, sugge);
        if (s.equals("Suggestion Changed")) {
            return ResponseEntity.ok(s);
        }else{
            return ResponseEntity.notFound().build();
        }
    }
    
}
