package com.esuggestion.suggestion.service;

import com.esuggestion.suggestion.model.Employee;
import com.esuggestion.suggestion.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public List<Employee> readAllEmployees() {
        return employeeRepository.findAll();
    }

    public Optional<Employee> readEmployeeById(UUID id) {
        return employeeRepository.findById(id);
    }

    public String createEmployee(Employee employee) {
        Optional<Employee> empl = employeeRepository.findByEmail(employee.getEmail());

        if (empl.isPresent()) {
            return "Employee Exist";
        }else{
            employeeRepository.save(employee);
            return "Employee success";
        }
    }

    public String deleteEmployee(UUID id) {
        Optional<Employee> s = employeeRepository.findById(id);
        if (s.isPresent()) {
            employeeRepository.deleteById(id);
            return "Employee Deleted";
        }else{
            return "failed to delete";
        }
    }


    public String changeEmployee( UUID id, Employee employee){
        Optional<Employee> s = employeeRepository.findById(id);
        if (s.isPresent()) {
            Employee ss = s.get();
            ss.setName(employee.getName());
            ss.setEmail(employee.getEmail());
            ss.setPassword(employee.getPassword());
            employeeRepository.save(ss);
            return "Employee Changed";
        }else{
            return "Employee Not Changed";
        }
    }
    
}
